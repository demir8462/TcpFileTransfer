using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.IO.Ports;
namespace YERISTASYON
{
    public partial class Form1 : Form
    {
        public static TextBox console;
        public PortReader pr;
        
        public Form1()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            console = textBox1;
            ModifyProgressBarColor.SetState(progressBar1,2);
            loadComs();
        }
        public static void writeConsole(string a)
        {
            console.AppendText(a);
            console.AppendText(Environment.NewLine);
        }
        
        public void loadComs()
        {
            listBox1.Items.Clear(); 
            foreach (string item in PortReader.getComs())
            {
                listBox1.Items.Add(item);
            }
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox5.Image = RotateImage(pictureBox5.Image, 1);
     

        }
        private Bitmap RotateImage(Image img,float angle)
        {
            
            Bitmap rbmp = new Bitmap(img.Width, img.Height);
            rbmp.SetResolution(img.HorizontalResolution, img.VerticalResolution);
            Graphics g = Graphics.FromImage(rbmp);
            g.TranslateTransform(rbmp.Width/2, rbmp.Height / 2);
            g.RotateTransform(angle);
            g.TranslateTransform(-rbmp.Width / 2, -rbmp.Height / 2);
            g.DrawImage(img, new PointF(0, 0));
            return rbmp;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (listBox1.SelectedItems.Count != 1)
                    return;
                pr = new PortReader(listBox1.SelectedItem.ToString(), 9600, 8,Parity.None, StopBits.One);
                pr.openPort();
            }catch(Exception ex)
            {
                writeConsole("BAGLANTIDA SORUN OLUSTU : " + ex.Message.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            loadComs();
        }
    }
    public static class ModifyProgressBarColor
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr w, IntPtr l);
        public static void SetState(this ProgressBar pBar, int state)
        {
            SendMessage(pBar.Handle, 1040, (IntPtr)state, IntPtr.Zero);
        }
    }
}